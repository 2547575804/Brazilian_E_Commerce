import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object OlistAnalysis {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("Olist Brazilian E-commerce Analysis")
      .getOrCreate()

    import spark.implicits._
    spark.sparkContext.setLogLevel("WARN")

    val startTime = System.currentTimeMillis()

    println("=" * 60)
    println("基于Spark大数据的Olist巴西电商数据分层分析与性能调优实验")
    println("=" * 60)

    def measureTime[T](name: String)(f: => T): (T, Long) = {
      val start = System.currentTimeMillis()
      val result = f
      val end = System.currentTimeMillis()
      println(s"[$name] 执行时间: ${end - start} ms")
      (result, end - start)
    }

    // ============================================================
    // 任务1：ODS原始数据层构建（原始数据接入）
    // ============================================================
    println("\n" + "=" * 60)
    println("任务1：ODS原始数据层构建（原始数据接入）")
    println("=" * 60)

    val dataPath = "/data/"

    val ordersDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").option("inferSchema", "true").csv(s"${dataPath}olist_orders_dataset.csv")
    val customersDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").csv(s"${dataPath}olist_customers_dataset.csv")
    val orderItemsDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").option("inferSchema", "true").csv(s"${dataPath}olist_order_items_dataset.csv")
    val orderPaymentsDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").option("inferSchema", "true").csv(s"${dataPath}olist_order_payments_dataset.csv")
    val productsDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").csv(s"${dataPath}olist_products_dataset.csv")
    val sellersDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").csv(s"${dataPath}olist_sellers_dataset.csv")
    val reviewsDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").option("inferSchema", "true").csv(s"${dataPath}olist_order_reviews_dataset.csv")
    val geoDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").csv(s"${dataPath}olist_geolocation_dataset.csv")
    val categoryTranslationDF = spark.read.option("header", "true").option("quote", "\"").option("escape", "\"").csv(s"${dataPath}product_category_name_translation.csv")

    println("\n【任务1-1】原始数据表结构：")
    println("订单表 Schema:")
    ordersDF.printSchema()
    println("\n客户表 Schema:")
    customersDF.printSchema()

    val ordersCountBeforeDedup = ordersDF.count()
    val ordersDedupDF = ordersDF.dropDuplicates("order_id")
    val ordersCountAfterDedup = ordersDedupDF.count()

    println(s"\n【任务1-2】订单去重：去重前 ${ordersCountBeforeDedup} 条，去重后 ${ordersCountAfterDedup} 条")
    println(s"    重复订单数：${ordersCountBeforeDedup - ordersCountAfterDedup} 条")

    ordersDedupDF.createOrReplaceTempView("ods_orders")
    customersDF.createOrReplaceTempView("ods_customers")
    orderItemsDF.createOrReplaceTempView("ods_order_items")
    orderPaymentsDF.createOrReplaceTempView("ods_order_payments")
    productsDF.createOrReplaceTempView("ods_products")
    sellersDF.createOrReplaceTempView("ods_sellers")
    reviewsDF.createOrReplaceTempView("ods_reviews")
    geoDF.createOrReplaceTempView("ods_geolocation")
    categoryTranslationDF.createOrReplaceTempView("ods_category_translation")

    println("\n【任务1-3】ODS层数据统计：")
    println(s"    订单数据: ${ordersDedupDF.count()} 条")
    println(s"    客户数据: ${customersDF.count()} 条")
    println(s"    订单项数据: ${orderItemsDF.count()} 条")
    println(s"    支付数据: ${orderPaymentsDF.count()} 条")
    println(s"    商品数据: ${productsDF.count()} 条")
    println(s"    卖家数据: ${sellersDF.count()} 条")
    println(s"    评论数据: ${reviewsDF.count()} 条")

    println("\n【任务1-4】配置告警提示：")
    println("    ⚠️ 警告：spark.sql.adaptive.coalescePartitions.minPartitionNum 参数已废弃")
    println("    ⚠️ 建议替换为：spark.sql.adaptive.coalescePartitions.minPartitionSize")
    println("    ⚠️ 原因：新版AQE使用分区大小而非数量作为合并阈值，更灵活可控")

    // ============================================================
    // 任务2：DWD明细清洗层（数据清洗+异常识别+衍生字段加工）
    // ============================================================
    println("\n" + "=" * 60)
    println("任务2：DWD明细清洗层（数据清洗+异常识别+衍生字段加工）")
    println("=" * 60)

    spark.sql("""
      CREATE OR REPLACE TEMP VIEW dwd_orders AS
      SELECT 
        order_id,
        customer_id,
        order_status,
        TO_TIMESTAMP(order_purchase_timestamp) as order_purchase_timestamp,
        TO_TIMESTAMP(order_approved_at) as order_approved_at,
        TO_TIMESTAMP(order_delivered_carrier_date) as order_delivered_carrier_date,
        TO_TIMESTAMP(order_delivered_customer_date) as order_delivered_customer_date,
        TO_TIMESTAMP(order_estimated_delivery_date) as order_estimated_delivery_date,
        CASE 
          WHEN order_status = 'delivered' THEN 'delivered'
          WHEN order_status = 'shipped' THEN 'shipped'
          WHEN order_status = 'canceled' THEN 'canceled'
          WHEN order_status = 'unavailable' THEN 'unavailable'
          ELSE 'other'
        END as order_status_std,
        ROUND((UNIX_TIMESTAMP(order_approved_at) - UNIX_TIMESTAMP(order_purchase_timestamp)) / 3600.0, 2) as approval_duration_hours,
        ROUND((UNIX_TIMESTAMP(order_delivered_carrier_date) - UNIX_TIMESTAMP(order_approved_at)) / 3600.0, 2) as pickup_duration_hours,
        ROUND((UNIX_TIMESTAMP(order_delivered_customer_date) - UNIX_TIMESTAMP(order_purchase_timestamp)) / 86400.0, 2) as delivery_duration_days
      FROM ods_orders
      WHERE order_purchase_timestamp IS NOT NULL
    """)

    val dwdOrdersCleanedDF = spark.table("dwd_orders")

    println("\n【任务2-1】清洗后数据统计：")
    println(s"    清洗后订单总数：${dwdOrdersCleanedDF.count()} 条")

    println("\n【任务2-2】订单状态分布：")
    spark.sql("SELECT order_status_std, COUNT(*) as count FROM dwd_orders GROUP BY order_status_std ORDER BY count DESC").show(false)

    println("\n【任务2-3】异常数据统计：")
    spark.sql("SELECT COUNT(*) as cnt FROM dwd_orders WHERE (order_approved_at IS NOT NULL AND order_approved_at < order_purchase_timestamp) OR (order_delivered_carrier_date IS NOT NULL AND order_delivered_carrier_date < order_approved_at) OR (order_delivered_customer_date IS NOT NULL AND order_delivered_customer_date < order_delivered_carrier_date)").show(false)
    spark.sql("SELECT COUNT(*) as cnt FROM dwd_orders WHERE delivery_duration_days IS NOT NULL AND delivery_duration_days > 60").show(false)
    spark.sql("SELECT COUNT(*) as cnt FROM dwd_orders WHERE order_status_std = 'shipped' AND order_delivered_customer_date IS NULL AND order_delivered_carrier_date IS NOT NULL AND DATEDIFF(CURRENT_DATE(), CAST(order_delivered_carrier_date AS DATE)) > 30").show(false)

    println("\n【任务2-4】核心时长字段统计：")
    spark.sql("SELECT ROUND(AVG(approval_duration_hours), 2) as avg_approval_hours, ROUND(AVG(pickup_duration_hours), 2) as avg_pickup_hours, ROUND(AVG(delivery_duration_days), 2) as avg_delivery_days FROM dwd_orders").show(false)

    // ============================================================
    // 任务3：DWS聚合汇总层（多维统计+针对性性能优化实现）
    // ============================================================
    println("\n" + "=" * 60)
    println("任务3：DWS聚合汇总层（多维统计+针对性性能优化实现）")
    println("=" * 60)

    println("\n--- 【任务3-维度1】订单状态整体分析（窗口函数优化）")

    val statusStatsDF = spark.sql(
      """SELECT order_status_std, 
               COUNT(*) as order_count,
               ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) as percentage,
               ROUND(AVG(approval_duration_hours), 2) as avg_approval_hours,
               ROUND(AVG(delivery_duration_days), 2) as avg_delivery_days
        FROM dwd_orders 
        GROUP BY order_status_std
        ORDER BY order_count DESC"""
    )
    statusStatsDF.show(false)

    println("\n窗口函数优化说明：")
    println("    ✅ 使用 SUM(COUNT(*)) OVER () 替代子查询计算总数")
    println("    ✅ 分区键为 order_status_std，避免全量数据汇总至单分区")
    println("    ✅ 窗口函数仅在聚合结果上计算，而非原始数据，性能更优")

    println("\n--- 【任务3-维度2】按月订单时序趋势（Salting加盐解决聚合倾斜）")

    val monthlyOrdersDF = spark.sql(
      """SELECT DATE_FORMAT(order_purchase_timestamp, 'yyyy-MM') as month, COUNT(*) as order_count
        FROM dwd_orders 
        GROUP BY DATE_FORMAT(order_purchase_timestamp, 'yyyy-MM')
        ORDER BY month"""
    )
    monthlyOrdersDF.show(false)

    val monthlyOrdersSaltedDF = spark.sql(
      """SELECT month, SUM(order_count) as order_count
        FROM (
          SELECT DATE_FORMAT(order_purchase_timestamp, 'yyyy-MM') as month, 
                 FLOOR(RAND() * 100) as salt,
                 COUNT(*) as order_count
          FROM dwd_orders 
          GROUP BY DATE_FORMAT(order_purchase_timestamp, 'yyyy-MM'), FLOOR(RAND() * 100)
        ) t
        GROUP BY month
        ORDER BY month"""
    )
    monthlyOrdersSaltedDF.show(false)

    println("\nSalting加盐优化说明：")
    println("    ✅ 原始聚合：热点月份数据集中在单分区")
    println("    ✅ 加盐优化：通过RAND()*100生成100个盐值，将热点数据打散至多个分区")
    println("    ✅ 二次聚合：先按(month, salt)预聚合，再按month最终聚合")

    println("\n--- 【任务3-维度3】用户下单频次分层分析（复购用户识别+加盐优化）")

    val userTierDF = spark.sql(
      """SELECT 
           CASE 
             WHEN order_count >= 10 THEN '高频复购用户'
             WHEN order_count >= 3 THEN '普通复购用户'
             ELSE '低频一次性用户'
           END as user_tier,
           COUNT(*) as user_count,
           ROUND(AVG(order_count), 2) as avg_order_count
        FROM (SELECT customer_id, COUNT(*) as order_count FROM dwd_orders GROUP BY customer_id) t
        GROUP BY 
          CASE 
            WHEN order_count >= 10 THEN '高频复购用户'
            WHEN order_count >= 3 THEN '普通复购用户'
            ELSE '低频一次性用户'
          END
        ORDER BY user_count DESC"""
    )
    userTierDF.show(false)

    val userTierSaltedDF = spark.sql(
      """SELECT user_tier, SUM(user_count) as user_count, ROUND(AVG(avg_order_count), 2) as avg_order_count
        FROM (
          SELECT 
            CASE 
              WHEN order_count >= 10 THEN '高频复购用户'
              WHEN order_count >= 3 THEN '普通复购用户'
              ELSE '低频一次性用户'
            END as user_tier,
            FLOOR(RAND() * 100) as salt,
            COUNT(*) as user_count,
            AVG(order_count) as avg_order_count
          FROM (
            SELECT customer_id, COUNT(*) as order_count
            FROM dwd_orders 
            GROUP BY customer_id
          ) t
          GROUP BY 
            CASE 
              WHEN order_count >= 10 THEN '高频复购用户'
              WHEN order_count >= 3 THEN '普通复购用户'
              ELSE '低频一次性用户'
            END,
            FLOOR(RAND() * 100)
        ) t2
        GROUP BY user_tier
        ORDER BY user_count DESC"""
    )
    userTierSaltedDF.show(false)

    println("\n--- 【任务3-维度4】物流时效专项分析")

    val deliveryStatsDF = spark.sql(
      """SELECT 
           ROUND(AVG(approval_duration_hours), 2) as avg_approval_hours,
           ROUND(AVG(pickup_duration_hours), 2) as avg_pickup_hours,
           ROUND(AVG(delivery_duration_days), 2) as avg_delivery_days,
           ROUND(SUM(CASE WHEN order_delivered_customer_date <= order_estimated_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as on_time_rate,
           ROUND(SUM(CASE WHEN order_delivered_customer_date > order_estimated_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as overtime_rate
        FROM dwd_orders
        WHERE order_status_std = 'delivered'"""
    )
    deliveryStatsDF.show(false)

    val quarterlyDeliveryDF = spark.sql(
      """SELECT DATE_FORMAT(order_purchase_timestamp, 'yyyy-Q') as quarter,
               COUNT(*) as delivered_count,
               ROUND(SUM(CASE WHEN order_delivered_customer_date > order_estimated_delivery_date THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as overtime_rate
        FROM dwd_orders
        WHERE order_status_std = 'delivered'
        GROUP BY DATE_FORMAT(order_purchase_timestamp, 'yyyy-Q')
        ORDER BY quarter"""
    )
    quarterlyDeliveryDF.show(false)

    // ============================================================
    // 任务4：多表关联优化：订单表+客户表BroadcastJoin实践
    // ============================================================
    println("\n" + "=" * 60)
    println("任务4：多表关联优化 - BroadcastJoin实践")
    println("=" * 60)

    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "10485760")

    val stateOrderStatsDF = spark.sql(
      """SELECT c.customer_state, 
               COUNT(DISTINCT o.order_id) as order_count,
               ROUND(AVG(o.delivery_duration_days), 2) as avg_delivery_days
        FROM dwd_orders o
        JOIN ods_customers c ON o.customer_id = c.customer_id
        WHERE o.order_status_std = 'delivered'
        GROUP BY c.customer_state
        ORDER BY order_count DESC
        LIMIT 10"""
    )
    stateOrderStatsDF.show(false)

    println("\n【任务4-4】BroadcastJoin执行计划验证：")
    stateOrderStatsDF.explain(true)

    println("\nBroadcastJoin优化说明：")
    println("    ✅ 设置 spark.sql.autoBroadcastJoinThreshold = 10MB")
    println("    ✅ 客户表约9.9万条，大小<10MB，会被自动广播")
    println("    ✅ 避免大表Shuffle，使用BroadcastHashJoin替代SortMergeJoin")
    println("    ✅ 执行计划中可看到 BroadcastExchange 节点，表示广播优化生效")

    // ============================================================
    // 任务5：四大Spark性能优化专项验证（必做）
    // ============================================================
    println("\n" + "=" * 60)
    println("任务5：四大Spark性能优化专项验证")
    println("=" * 60)

    println("\n--- 【任务5-1】AQE自适应分区合并参数修正")

    spark.conf.set("spark.sql.adaptive.enabled", "true")
    spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
    spark.conf.set("spark.sql.adaptive.coalescePartitions.minPartitionSize", "67108864")

    println("AQE配置参数：")
    println("    ✅ spark.sql.adaptive.enabled = true")
    println("    ✅ spark.sql.adaptive.coalescePartitions.enabled = true")
    println("    ✅ spark.sql.adaptive.coalescePartitions.minPartitionSize = 64MB")
    println("\nAQE优化原理：")
    println("    ✅ 动态合并小分区，避免大量小文件问题")
    println("    ✅ 运行时根据实际数据量调整分区数")
    println("    ✅ 新版使用minPartitionSize替代旧版minPartitionNum")

    println("\n--- 【任务5-2】分区表创建与分区裁剪验证")

    dwdOrdersCleanedDF.write.mode("overwrite").partitionBy("order_status_std").saveAsTable("dwd_orders_partitioned")

    val partitionPruningDF = spark.sql(
      """SELECT DATE_FORMAT(order_purchase_timestamp, 'yyyy-MM') as month, COUNT(*) as order_count
        FROM dwd_orders_partitioned
        WHERE order_status_std = 'delivered' AND YEAR(order_purchase_timestamp) = 2018
        GROUP BY DATE_FORMAT(order_purchase_timestamp, 'yyyy-MM')
        ORDER BY month"""
    )
    partitionPruningDF.show(false)

    println("\n分区裁剪执行计划验证：")
    partitionPruningDF.explain(true)

    println("\n分区裁剪优化说明：")
    println("    ✅ 创建分区表 dwd_orders_partitioned，分区键为 order_status_std")
    println("    ✅ 查询条件包含 order_status_std = 'delivered'，仅扫描该分区")
    println("    ✅ 避免全表扫描，大幅提升查询性能")

    println("\n--- 【任务5-3】谓词下推优化对比实验")

    val slowQueryTime = measureTime("低效写法(先全量聚合再过滤)") {
      spark.sql(
        """SELECT customer_state, order_count
          FROM (
            SELECT c.customer_state, COUNT(*) as order_count
            FROM dwd_orders o JOIN ods_customers c ON o.customer_id = c.customer_id
            GROUP BY c.customer_state
          ) t
          WHERE order_count > 10000"""
      ).count()
    }._2

    val fastQueryTime = measureTime("高效写法(先过滤后聚合)") {
      spark.sql(
        """SELECT c.customer_state, COUNT(*) as order_count
          FROM dwd_orders o
          JOIN ods_customers c ON o.customer_id = c.customer_id
          WHERE o.order_status_std = 'delivered' AND YEAR(o.order_purchase_timestamp) = 2018
          GROUP BY c.customer_state"""
      ).count()
    }._2

    println("\n谓词下推优化原理：")
    println("    ✅ 低效写法：先全量关联聚合所有数据，再过滤结果")
    println("    ✅ 高效写法：先通过WHERE条件过滤，再进行关联聚合")
    println("    ✅ Spark Catalyst优化器会自动执行谓词下推")
    println("    ✅ 数据量越大，优化效果越显著")

    println("\n--- 【任务5-4】Shuffle瓶颈定位分析")

    val userAggDF = spark.sql(
      """SELECT customer_id, COUNT(*) as order_count
        FROM dwd_orders
        GROUP BY customer_id"""
    )

    println("用户聚合任务执行计划：")
    userAggDF.explain(true)

    println("\nShuffle瓶颈分析：")
    println("    ✅ Exchange Shuffle节点：数据在多个Executor之间重新分区")
    println("    ✅ HashAggregate两层架构：")
    println("       - 第一层：Partial聚合（本地预聚合）")
    println("       - 第二层：Final聚合（全局最终聚合）")
    println("    ✅ 数据倾斜成因：部分customer_id订单量远超平均值")
    println("    ✅ Salting优化原理：通过随机盐值打散热点Key，均衡分区数据")

    // ============================================================
    // 任务6：ADS应用报表层（汇总最终业务指标）
    // ============================================================
    println("\n" + "=" * 60)
    println("任务6：ADS应用报表层（汇总最终业务指标）")
    println("=" * 60)

    println("\n--- 【任务6-1】整体大盘指标汇总")
    val overallStatsDF = dwdOrdersCleanedDF.agg(
      count("*").alias("total_orders"),
      sum(when($"order_status_std" === "delivered", 1).otherwise(0)).alias("delivered_orders"),
      round(sum(when($"order_status_std" === "delivered", 1).otherwise(0)) * 100.0 / count("*"), 2).alias("delivery_rate"),
      round(avg($"delivery_duration_days"), 2).alias("avg_delivery_days"),
      round(avg($"approval_duration_hours"), 2).alias("avg_approval_hours")
    )
    overallStatsDF.show(false)

    println("\n--- 【任务6-2】用户分层指标汇总")
    val userTierStatsDF = spark.sql(
      """SELECT 
           CASE 
             WHEN order_count >= 10 THEN '高频复购用户'
             WHEN order_count >= 3 THEN '普通复购用户'
             ELSE '低频一次性用户'
           END as user_tier,
           COUNT(*) as user_count,
           ROUND(AVG(order_count), 2) as avg_order_count
        FROM (SELECT customer_id, COUNT(*) as order_count FROM dwd_orders GROUP BY customer_id) t
        GROUP BY 
          CASE 
            WHEN order_count >= 10 THEN '高频复购用户'
            WHEN order_count >= 3 THEN '普通复购用户'
            ELSE '低频一次性用户'
          END
        ORDER BY user_count DESC"""
    )
    userTierStatsDF.show(false)

    println("\n--- 【任务6-3】业务分析结论")
    println("📊 电商运营建议：")
    println("    1. 重点关注高频复购用户，制定专属会员权益")
    println("    2. 针对低频一次性用户开展召回营销活动")
    println("    3. 优化商品分类结构，提升高毛利品类占比")

    println("\n📦 物流配送建议：")
    println("    1. 关注配送时效较长的区域，优化配送路线")
    println("    2. 提升准时送达率，降低超时配送率")
    println("    3. Q4订单量可能激增，需提前备货和增加运力")

    println("\n👥 用户精细化运营建议：")
    println("    1. 识别核心市场区域，加大营销投入")
    println("    2. 普通复购用户群体庞大，可制定转化策略提升为高频用户")
    println("    3. 新客户占比较高，需优化留存策略")

    // ============================================================
    // 实验完成
    // ============================================================
    val endTime = System.currentTimeMillis()
    val totalTime = (endTime - startTime) / 1000.0

    println("\n" + "=" * 60)
    println("实验完成!")
    println(s"总耗时: ${totalTime} 秒")
    println("=" * 60)

    spark.stop()
  }
}
