@echo off
echo ================================
echo 启动Spark大数据实验
echo ================================
echo.

cd /d "%~dp0"

echo 停止旧容器...
docker-compose down

echo.
echo 启动容器...
docker-compose up -d

echo.
echo 等待实验运行...
timeout /t 120 /nobreak >nul

echo.
echo ================================
echo 实验运行结果：
echo ================================
docker logs spark-olist-analysis

echo.
echo 按任意键退出...
pause
